package com.ayah.daos;

public class MessageDAO {
}
