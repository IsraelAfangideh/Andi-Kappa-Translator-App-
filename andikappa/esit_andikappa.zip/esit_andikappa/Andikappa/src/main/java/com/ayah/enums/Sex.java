package com.ayah.enums;

public enum Sex {
    Male,
    Female,

    Incognito

}
