package com.ayah.models;

public class Message {
    //List of Users involved in the message


    //Time(We will display messages ranked by time)

    //String messagecontent


}
